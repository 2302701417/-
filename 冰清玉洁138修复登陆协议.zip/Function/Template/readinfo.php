<?php
$templatename = array(
    'bqyj'
    //
);
$templatek = array(
    'bqyj_alias' => 'bqyj',
    'bqyj_template_name' => '榴莲云平台&太子收费模板',
    'bqyj_template_img' => 'http://h2302701417.kuaiyunds.com/h2302701417/bqyj1.63/bqyj_lly/808.jpg',
    #
);
?>
