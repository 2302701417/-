<?php
if (C('webindex') == 'Function/Template/index_bqyj.php') {
    return array(
        'alias' => 'bqyj',
        'template_name' => '榴莲云平台&太子收费模板',
        'template_author' => '榴莲云&太子',
        'template_url' => 'http://mz.1ssl.cc/',
        'template_readme' => '榴莲云平台响应式首页,简洁风格,已接入CDN加速',
        'template_img' => 'http://h2302701417.kuaiyunds.com/h2302701417/bqyj1.63/bqyj_lly/808.jpg',
		);
}
#
?>
